for file in *.txt; do ./ba.sh "$file"; done
